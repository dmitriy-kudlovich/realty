import controller from "../favs/favsController";

export default function (state) {
  controller(state);
}
