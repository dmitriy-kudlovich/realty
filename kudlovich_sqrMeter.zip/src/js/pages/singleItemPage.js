import controller from "../singleItem/singleItemController";

export default function (state) {
  controller(state);
}
