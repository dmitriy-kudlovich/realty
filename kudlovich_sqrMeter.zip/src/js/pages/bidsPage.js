import bidsController from "../bids/bidsController";

export default function () {
  bidsController();
}
