export default function () {
  document.querySelector("#app").innerHTML = "Error 404";
}
